# Reactjs基础环境搭建

1、安装nodejs

2、cmd到工程下并输入：npm install

3、执行打包命令：webpack

包含了webpack、babel-jsx、babel-es6、reactjs等等的配置

供初学者入门使用，使用记得star，谢谢！
